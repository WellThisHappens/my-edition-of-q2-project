
public class rock {

}
