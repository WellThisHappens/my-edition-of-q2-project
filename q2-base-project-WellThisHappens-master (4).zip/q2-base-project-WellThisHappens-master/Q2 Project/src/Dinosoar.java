import java.awt.geom.AffineTransform;
import java.net.URL;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;

public class Dinosoar {

	public int x, y;
	public int vy;
	private int height;
	private int width;
	private Image img;
	private Image img2;
	private AffineTransform tx;
	private boolean ducking = false;

	public Dinosoar(int x, int y) {
		this.x = x;
		this.y = y;

		img = getImage("/imgs/dino.png"); // load the image for dino
		img2 = getImage("/imgs/the real ducking dino.gif");
		tx = AffineTransform.getTranslateInstance(x, y);
		init(x, y);

	}
	/*
	 * private Dinosoar() { y = 0; height = 30; width = 10; }
	 */

//public int getY () {
	// return y;
//}
	/*
	 * public int getHeight () { return height; } public int getWidth () { return
	 * width; }
	 */
//public void duck (Graphics g) {
	public void duck() {
		
		
		if (y < 276) {
		
			if (vy < 0) {
			vy *= -2;
			}
			if (vy > 0) {
				vy *= 2;
			}
			if (vy == 0) {
				vy += 10;
			}
				
		}
		if (y >= 276) {
			ducking = true;
			y = 318;

		}
	}

	public void unduck() {
		
		if (ducking == true) {
		ducking = false;
		y = 276;
		}
	}

	public void jump() {
		if (ducking == false) {
		if (y >= 276) {
			vy = -26;

		}
		}
	}

	public void paint(Graphics g) {
		// these are the 2 lines of code needed draw an image on the screen
		Graphics2D g2 = (Graphics2D) g;

		// call update to update the actually picture location
		update();
		if (ducking == false) {			
			//tx.scale(.5, .5);
			g2.drawImage(img, tx, null);

		}else {
			tx.scale(2.1, 2.1);
			g2.drawImage(img2, tx, null);
		}
	}

	public void update() {
		y += vy;

		// if (y < 276) {
		// vy = 4;
		// } else {
		if (y < 276) {
			vy += 2;
		}
		if (y >= 276) {
			if (ducking == false) {
				y = 276;
			}
			vy = 0;
		}
		// if (y <= 100 ) {
		// vy = 8;
		// }
		// tx.setToTranslation(x, y);
		// tx.scale(.5 , .5);
		tx.setToTranslation(x, y);
		tx.scale(.25, .25);
	}

	private void init(double a, double b) {
		tx.setToTranslation(a, b);
		tx.scale(.5, .5);
	}

	private Image getImage(String path) {
		Image tempImage = null;
		try {
			URL imageURL = Dinosoar.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempImage;
	}

}