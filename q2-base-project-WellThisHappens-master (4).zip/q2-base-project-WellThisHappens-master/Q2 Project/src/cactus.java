import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.net.URL;

public class cactus {
public int x, y;
private Image img;
private AffineTransform tx;






public cactus(int x, int y) {
	this.x = x;
	this.y = y;
	
	
	
	
	
	img = getImage("/imgs/cactus.png"); //load the image 
	tx = AffineTransform.getTranslateInstance(x, y );
	init(x, y); 				//initialize the location of the image
								//use your variables
	
}
private void init(double a, double b) {
	tx.setToTranslation(a, b);
	tx.scale(2.7, 2.5);
}




private Image getImage(String path) {
	Image tempImage = null;
	try {
		URL imageURL = cactus.class.getResource(path);
		tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return tempImage;
}
}
